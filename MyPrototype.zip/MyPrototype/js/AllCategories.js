const list = document.querySelector("#categories-list");

Object.values(categoriesConfig).forEach(cat => {
  const div = document.createElement("div");
  div.className = "category-card"; // estilo específico para todas categorias
  div.innerText = cat.title;

  // Se quiser, adicionar ícone da categoria
  const img = document.createElement("img");
  img.src = cat.icon;
  div.prepend(img);

  list.appendChild(div);
});
