alert("category.js carregou");

const params = new URLSearchParams(window.location.search);
const tipo = params.get("tipo");

const config = categoriesConfig[tipo];

if (!config) {
  document.body.innerHTML = "<h2>Categoria não encontrada</h2>";
  throw new Error("Tipo inválido");
}

// Configura topbar
document.querySelector(".topbar").style.background = config.themeColor;
document.querySelector("#category-title").innerText = config.title;
document.querySelector("#category-icon").src = config.icon;

const list = document.querySelector("#items-list");
list.innerHTML = ""; // Limpa antes

config.subtitulos.forEach(sub => {
  // Cria subtítulo
  const h3 = document.createElement("h3");
  h3.innerText = sub.subtitulo;
  list.appendChild(h3);

  // Cria itens do subtítulo
  sub.items.forEach(item => {
    const div = document.createElement("div");
    div.className = "item";

    // Texto do item
    const span = document.createElement("span");
    span.innerText = item.name;
    div.appendChild(span);

    // Botão de adicionar
    const btn = document.createElement("button");
    btn.className = "add-btn";
    btn.innerText = "+"; // ou "Adicionar"
    div.appendChild(btn);

    list.appendChild(div);
  });
});
