const categoriesConfig = {
  bebidas: {
    title: "Bebidas",
    themeColor: "rgb(11, 149, 224)",
    subtitulos: [
      {
        subtitulo: "Bebidas alcoólicas",
        items: [
          { name: "Cerveja" },
          { name: "Cachaça" },
          { name: "Whisky" },
        ]
      },
      {
        subtitulo: "Bebidas não alcoólicas",
        items: [
          { name: "Coca-Cola" },
          { name: "Suco de abacaxi" },
          { name: "Água" },
        ]
      }
    ]
  },

  hortifruti: {
    title: "Hortifruti",
    themeColor: "rgb(21, 175, 34)",
    subtitulos: [
      {
        subtitulo: "Verduras",
        items: [
          { name: "Alface" },
          { name: "Couve" },
          { name: "Espinafre" }
        ]
      },
      {
        subtitulo: "Legumes",
        items: [
          { name: "Cenoura"},
          { name: "Beterarba"}
        ]
      },
      {
        subtitulo: "Frutas",
        items: [
          { name: "Maça"},
          { name: "Banana"},
          { name: "Abacaxi"}
        ]
      }
    ]
  },

  padaria: {
    title: "Padaria",
    themeColor: "rgb(96, 55, 36)",
    subtitulos: [
      {
        subtitulo: "Paes",
        items: [
          { name: "Pão frances"},
          { name: "Pão de forma"},
          { name: "Pão integral"},
        ]
      },
      {
        subtitulo: "Salgados e Massas",
        items: [
          { name: "Coxinha"},
          { name: "Enroladinho de salsicha"},
          { name: "Pastel assado"}
        ]
      }
    ]
  },


  acougue: {
    title: "Açougue",
    themeColor: "rgb(181, 10, 10)",
    subtitulos: [
      {
        subtitulo: "Carnes Bovinas",
        items: [
        { name: "Bife" },
        { name: "Carne moída" },
        { name: "Picanha" },
      ]
    },
    {
      subtitulo: "Carnes de Aves",
      items: [
        { name: "Frango inteiro"},
        { name: "Peito de frango"},
        { name: "Coza e sobrecoxa"},
      ]
    }
  ]
} 
}
