//' 

/*
→ somente dados (títulos, ícones, itens)
→ lógica (ler a URL, identificar a categoria, montar a tela)
*/

//Ler o tipo da categoria (JS)

// pega o parâmetro ?tipo=...
const params = new URLSearchParams(window.location.search);
const tipo = params.get("tipo");

// busca a categoria no mapeamento
const category = categoriesData[tipo];

if (!category) {
  document.getElementById("category-title").innerText = "Categoria não encontrada";
} else {
  // título
  document.getElementById("category-title").innerText = category.title;

  // ícone
  document.getElementById("category-icon").src = category.icon;

  // lista de itens
  const list = document.getElementById("items-list");
  list.innerHTML = "";

  category.items.forEach(item => {
    const div = document.createElement("div");
    div.className = "item";
    div.innerText = item.name;
    list.appendChild(div);
  });
}
