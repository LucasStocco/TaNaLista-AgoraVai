document.addEventListener("DOMContentLoaded", () => {

    // ---- ELEMENTOS FIXOS ----
    const cardsContainer = document.querySelector(".content");

    const overlay = document.getElementById("overlay");
    const sheet = document.getElementById("actionSheet");
    const sheetTitle = document.getElementById("sheetTitle");

    const overlayRename = document.getElementById("overlayRename");
    const renameSheet = document.getElementById("renameSheet");
    const renameInput = document.getElementById("renameInput");
    const saveRenameBtn = document.getElementById("saveRenameBtn");
    const cancelRenameBtn = document.getElementById("cancelRenameBtn");

    const addListBtn = document.getElementById("addListBtn");

    const popupCreate = document.getElementById("popupCreate");
    const confirmCreateBtn = document.getElementById("confirmCreateBtn");
    const cancelCreateBtn = document.getElementById("cancelCreateBtn");
    const newListInput = document.getElementById("newListInput");
    const btnRename = document.getElementById("btnRename");


    let currentCard = null;


    // ------------------ PROGRESS BAR ------------------
    function initProgressBars(root = document) {
        root.querySelectorAll(".progress-bar").forEach(bar => {
            const value = bar.getAttribute("data-progress") || "0";
            bar.style.width = parseFloat(value) + "%";
        });
    }




    // --------------- ACTIONSHEET -----------------
    function openSheet(card) {
        currentCard = card;

        const h3 = card.querySelector("h3");
        sheetTitle.textContent = h3 ? h3.textContent : "";

        overlay.classList.remove("hidden");
        sheet.classList.remove("hidden");

        setTimeout(() => {
            overlay.style.opacity = 1;
            sheet.style.bottom = "0px";
        }, 10);
    }

    btnRename.addEventListener("click", () => {
        closeSheet();                // 🔥 fecha o sheet antes de abrir o rename
        openRename(currentCard);     // 🔥 abre o rename
    });

    function closeSheet() {
        overlay.style.opacity = 0;
        sheet.style.bottom = "-300px";

        setTimeout(() => {
            overlay.classList.add("hidden");
            sheet.classList.add("hidden");
        }, 250);
    }

    overlay.addEventListener("click", closeSheet);


    // --------------- RENAME -----------------
    function openRename(cardElement) {
        currentCard = cardElement;

        sheetTitle.textContent = "Renomear";
        renameInput.value = currentCard.querySelector("h3").textContent;

        overlayRename.classList.remove("hidden");
        renameSheet.classList.remove("hidden");

        setTimeout(() => {
            overlayRename.style.opacity = 1;
            renameSheet.style.bottom = "0px";
        }, 20);

        renameInput.focus();
    }

    function closeRename() {
        overlayRename.style.opacity = 0;
        renameSheet.style.bottom = "-300px";

        setTimeout(() => {
            overlayRename.classList.add("hidden");
            renameSheet.classList.add("hidden");
        }, 250);
    }

    overlayRename.addEventListener("click", closeRename);
    cancelRenameBtn.addEventListener("click", closeRename);

    saveRenameBtn.addEventListener("click", () => {
        const newName = renameInput.value.trim();
        if (newName === "") return;

        currentCard.querySelector("h3").textContent = newName;
        closeRename();
    });



    // ------------------ CLICAR NO CARD → ABRIR PÁGINA ------------------
    function attachCardEvents(card) {
        if (card.__attached) return; // evita duplicação de eventos
        card.__attached = true;

        const menuBtn = card.querySelector(".menu-btn");
        const titleEl = card.querySelector("h3");

        // Clicar no ⋮
        if (menuBtn) {
            menuBtn.addEventListener("click", (e) => {
                e.stopPropagation();
                openSheet(card);
            });
        }

        // Clicar no card → abrir lista.html
        card.addEventListener("click", () => {
            if (!titleEl) return;
            const nome = encodeURIComponent(titleEl.textContent);
            window.location.href = `/lista/listaL.html?nome=${nome}`;
        });
    }


    // Ativar eventos nos cards existentes
    document.querySelectorAll(".card").forEach(attachCardEvents);

    initProgressBars();



    // ------------------ POPUP CRIAR LISTA ------------------
    function abrirPopup() {
        popupCreate.classList.remove("hidden");
        setTimeout(() => { popupCreate.style.opacity = 1; }, 10);

        newListInput.value = "";
        newListInput.focus();
    }

    function fecharPopup() {
        popupCreate.style.opacity = 0;
        setTimeout(() => popupCreate.classList.add("hidden"), 200);
    }

    addListBtn.addEventListener("click", abrirPopup);
    cancelCreateBtn.addEventListener("click", fecharPopup);


    confirmCreateBtn.addEventListener("click", () => {
        const nome = newListInput.value.trim();
        if (nome === "") return;

        const card = document.createElement("div");
        card.classList.add("card");

        card.innerHTML = `
            <div class="card-header">
                <h3>${nome}</h3>
                <div class="menu-btn" data-list="${nome}">⋮</div>
            </div>
            <div class="progress">
                <div class="progress-bar" data-progress="0"></div>
            </div>
            <span class="counter">0/0</span>
        `;

        cardsContainer.appendChild(card);

        initProgressBars(card);
        attachCardEvents(card);

        fecharPopup();
    });

});
