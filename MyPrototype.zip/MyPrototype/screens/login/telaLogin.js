let etapaAtual = 0;
const etapas = document.querySelectorAll(".etapa");
const bolinhas = document.querySelectorAll(".bolinha");

function mostrarEtapa(n) {
  etapas.forEach(e => e.classList.remove("ativa"));
  bolinhas.forEach(b => b.classList.remove("ativa"));

  etapas[n].classList.add("ativa");
  bolinhas[n].classList.add("ativa");
}

function proximaEtapa() {
  etapaAtual = (etapaAtual + 1) % etapas.length;
  mostrarEtapa(etapaAtual);
}

setInterval(proximaEtapa, 2500);
