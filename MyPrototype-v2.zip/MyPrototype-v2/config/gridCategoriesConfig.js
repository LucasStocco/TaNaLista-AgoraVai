// DADOS DO GRID

const gridCategories = [
  // Cada chave é uma categoria
  {
    name: "Bebidas",
    icon: "../../assets/icons/iconBebidas-categorias.png",
    link: "categoria.html?categoria=bebidas"
  },
  {
    name: "Hortifruti",
    icon: "../../assets/icons/iconHortifruti-categorias.png",
    link: "categoria.html?categoria=hortifruti"
  },
  {
    name: "Padaria",
    icon: "../../assets/icons/iconPadaria-categorias.png",
    link: "categoria.html?categoria=padaria"
  },
  {
    name: "Açougue",
    icon: "../../assets/icons/iconAcougue-categorias.png",
    link: "categoria.html?categoria=acougue"
  },
  {
    name: "Laticinios",
    icon: "../../assets/icons/iconLaticinios-categorias.png",
    link: "categoria.html?categoria=laticinios"
  },
  {
    name: "Mercearia",
    icon: "../../assets/icons/iconMercearia-categorias.png",
    link: "categoria.html?categoria=mercearia"
  },
  {
    name: "Higiene",
    icon: "../../assets/icons/iconHigiene-categorias.png",
    link: "categoria.html?categoria=higiene"
  },
  {
    name: "Limpeza",
    icon: "../../assets/icons/iconLimpeza-categorias.png",
    link: "categoria.html?categoria=limpeza"
  },
  {
    name: "Pets",
    icon: "../../assets/icons/iconPets-categorias.png",
    link: "categoria.html?categoria=pets"
  },
  {
    name: "Sazonal",
    icon: "../../assets/icons/iconSazonal-categorias.png",
    link: "categoria.html?categoria=sazonal"
  },
  {
    name: "Outros",
    icon: "../../assets/icons/iconOutros-categorias.png",
    link: "categoria.html?categoria=outros"
  },
  {
    name: "Bebês",
    icon: "../../assets/icons/iconBebes-categorias.png",
    link: "categoria.html?categoria=bebes"
  }
];
