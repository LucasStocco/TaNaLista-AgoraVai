alert("controller carregou");

// Pega os parâmetros da URL
const params = new URLSearchParams(window.location.search);
const categoriaKey = params.get("categoria");

// Busca categoria
const category = categoriesData[categoriaKey];

// Elementos
const titleEl = document.getElementById("category-title");
const itemsList = document.getElementById("items-list");

if (!category) {
  titleEl.innerText = "Categoria não encontrada";
} else {
  // Título
  titleEl.innerText = category.title;

  // Cor do topo
  document.querySelector(".topbar").style.backgroundColor =
    category.themeColor;

  // Limpa lista
  itemsList.innerHTML = "";

  // Subtítulos + itens
  category.subtitulos.forEach(sub => {
    const subtitle = document.createElement("h2");
    subtitle.innerText = sub.subtitulo;
    itemsList.appendChild(subtitle);

    sub.items.forEach(item => {
      const div = document.createElement("div");
      div.className = "item";
      div.innerText = item.name;
      itemsList.appendChild(div);
    });
  });
}
