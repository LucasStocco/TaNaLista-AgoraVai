const categoriesList = document.getElementById("categories-list");

// Limpa antes de renderizar
categoriesList.innerHTML = "";

// Itera pelos dados
gridCategories.forEach(cat => {
  const card = document.createElement("a");
  card.href = cat.link; // link para categoria
  card.className = "category-card";

  // Imagem
  const img = document.createElement("img");
  img.src = cat.icon;
  img.alt = cat.name;

  // Nome da categoria
  const span = document.createElement("span");
  span.innerText = cat.name;

  // Adiciona img e span no card
  card.appendChild(img);
  card.appendChild(span);

  // Adiciona card no grid
  categoriesList.appendChild(card);
});
