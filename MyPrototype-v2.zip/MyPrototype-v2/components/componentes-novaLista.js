// Componente para criar input de lista
function InputNovaLista(id, placeholder) {
  const wrapper = document.createElement("div");
  wrapper.className = "input-componente";

  const label = document.createElement("label");
  label.setAttribute("for", id);
  label.textContent = "Nome da Lista:";
  wrapper.appendChild(label);

  const input = document.createElement("input");
  input.type = "text";
  input.id = id;
  input.placeholder = placeholder;
  wrapper.appendChild(input);

  return wrapper;
}

// Componente para criar botão
function BotaoNovaLista(text) {
  const button = document.createElement("button");
  button.className = "botao-componente";
  button.textContent = text;
  button.id = "btnSalvar";

  // Evento de teste (alerta)
  button.addEventListener("click", () => {
    const nomeLista = document.querySelector("#nomeLista").value;
    if (nomeLista) {
      alert(`Lista criada: ${nomeLista}`);
    } else {
      alert("Digite um nome para a lista!");
    }
  });

  return button;
}

// Componente que junta tudo
function TelaNovaLista(containerId) {
  const container = document.querySelector(containerId);
  container.appendChild(InputNovaLista("nomeLista", "Digite o nome da lista"));
  container.appendChild(BotaoNovaLista("Criar Lista"));
}
