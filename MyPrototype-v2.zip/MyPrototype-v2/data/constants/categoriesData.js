const categoriesData = {
  // Seção de Bebidas
  bebidas: {
    title: "Bebidas",
    themeColor: "rgb(11, 149, 224)",
    subtitulos: [
      {
        subtitulo: "Bebidas alcoólicas",
        items: [
          { name: "Cerveja" },
          { name: "Cachaça" },
          { name: "Whisky" }
        ]
      },
      {
        subtitulo: "Bebidas não alcoólicas",
        items: [
          { name: "Coca-Cola" },
          { name: "Suco de abacaxi" },
          { name: "Água" }
        ]
      }
    ]
  },

  // Seção de Hortifruti
  hortifruti: {
    title: "Hortifruti",
    themeColor: "rgb(21, 175, 34)",
    subtitulos: [
      {
        subtitulo: "Verduras",
        items: [
          { name: "Alface" },
          { name: "Couve" },
          { name: "Espinafre" }
        ]
      },
      {
        subtitulo: "Legumes",
        items: [
          { name: "Cenoura" },
          { name: "Beterraba" }
        ]
      },
      {
        subtitulo: "Frutas",
        items: [
          { name: "Maçã" },
          { name: "Banana" },
          { name: "Abacaxi" }
        ]
      }
    ]
  },

  // Seção de Padaria
  padaria: {
    title: "Padaria",
    themeColor: "rgb(96, 55, 36)",
    subtitulos: [
      {
        subtitulo: "Pães",
        items: [
          { name: "Pão francês" },
          { name: "Pão de forma" },
          { name: "Pão integral" }
        ]
      },
      {
        subtitulo: "Salgados e massas",
        items: [
          { name: "Coxinha" },
          { name: "Enroladinho de salsicha" },
          { name: "Pastel assado" }
        ]
      }
    ]
  },

  // Seção de açougue
  acougue: {
    title: "Açougue",
    themeColor: "rgb(181, 10, 10)",
    subtitulos: [
      {
        subtitulo: "Carnes bovinas",
        items: [
          { name: "Bife" },
          { name: "Carne moída" },
          { name: "Picanha" }
        ]
      },
      {
        subtitulo: "Carnes de aves",
        items: [
          { name: "Frango inteiro" },
          { name: "Peito de frango" },
          { name: "Coxa e sobrecoxa" }
        ]
      }
    ]
  },

  // Seção de Laticínios
  laticinios: {
    title: "Laticínios",
    themeColor: "rgb(184, 204, 29)",
    subtitulos: [
      {
        subtitulo: "Laticínios",
        items: [
          { name: "Leite" },
          { name: "Iogurte" },
          { name: "Manteiga" }
        ]
      },
      {
        subtitulo: "Queijos",
        items: [
          { name: "Queijo Mussarela" },
          { name: "Queijo Prato" },
          { name: "Requeijão" }
        ]
      }
    ]
  },

  // Seção de Mercearia
  mercearia: {
    title: "Mercearia",
    themeColor: "rgb(120, 46, 0)",
    subtitulos: [
      {
        subtitulo: "Grãos e Massas",
        items: [
          { name: "Arroz" },
          { name: "Feijão" },
          { name: "Macarrão" }
        ]
      },
      {
        subtitulo: "Temperos e Condimentos",
        items: [
          { name: "Sal" },
          { name: "Açúcar" },
          { name: "Molho de tomate" }
        ]
      }
    ]
  },

  // Seção de Higiene
  higiene: {
    title: "Higiene",
    themeColor: "rgb(0, 62, 120)",
    subtitulos: [
      {
        subtitulo: "Higiene Pessoal",
        items: [
          { name: "Sabonete"},
          { name: "Shampoo"},
          { name: "Pasta de dente"}
        ]
      },
      {
        subtitulo: "Cuidados Pessoais",
        items: [
          { name: "Desodorante"},
          { name: "Creme hidratante"},
          { name: "Protetor solar"}
        ]
      }
    ]
  },

  // Seção de Limpeza
  limpeza: {
    title: "Limpeza",
    themeColor: "rgb(0, 120, 56)",
    subtitulos: [
      {
        subtitulo: "Limpeza Geral",
        items: [
          { name: "Detergente liquido"},
          { name: "Desinfetante"},
          { name: "Multioso"}
        ]
      },
      {
        subtitulo: "Lavanderia",
        items: [
          { name: "Sabão em pó"},
          { name: "Amaciante"},
          { name: "Alvejante"}
        ]
      }
    ]
  },

  // Seção de Pets
  pets: {
    title: "Pets",
    themeColor: "rgba(184, 72, 3, 0.77)",
    subtitulos: [
      {
        subtitulo: "Alimentos",
        items: [
          { name: "Ração para cachorro"},
          { name: "Ração para peixe"},
          { name: "Ração para gato"}
        ]
      },
      {
        subtitulo: "Higiene e Cuidados",
        items: [
          { name: "Shampoo para pets"},
          { name: "Areia sanitária"},
          { name: "Escova"}
        ]
      },
      {
        subtitulo: "Acessórios",
        items: [
          { name: "Bolinha de borracha"},
          { name: "Osso de brinquedo"},
          { name: "Coleira"}
        ]
      }
    ]
  },

  // Seção sazonal
  sazonal: {
    title: "Natal",
    themeColor: "rgb(32, 210, 223)",
    subtitulos: [
      {
        subtitulo: "Natal",
        items: [
        { name: "Panetone"},
        { name: "Chocotone"}
        ]
      },
      {
        subtitulo: "Páscoa",
        items: [
          { name: "Ovos de chocolate"},
          { name: "Coelhinhos de chocolate"}
        ]
      },
      {
        subtitulo: "Festas",
        items: [
          { name: "Balões"},
          { name: "Velas de festa"}
        ]
      }
    ]
  },

  // Seção Outros
  outros: {
    title: "Outros",
    themeColor: "rgba(119, 119, 119, 0.61)",
    subtitulos: [
      {
        subtitulo: "Utensílios Domésticos",
        items: [
          { name: "Pilhas"},
          { name: "Velas de cozinha"},
          { name: "Fósforos"}
        ]
      },
      {
        subtitulo: "Descartáveis",
        items: [
          { name: "Sacos plásticos"},
          { name: "Papel alumínio"},
          { name: "Guardanapos"}
        ]
      }
    ]
  },

  // Seção de Bebês
  bebes: {
    title: "Bebês",
    themeColor: "rgb(166, 16, 183)",
    subtitulos: [
      {
        subtitulo: "Alimentação",
        items: [
          { name: "Leite infaltil"},
          { name: "Papinha pronta"},
          { name: "Fórmula láctea"}
        ]
      },
      {
        subtitulo: "Higiene",
        items: [
          { name: "Fraldas"},
          { name: "Lenços umedecidos"},
          { name: "Sabonete liquído infaltil"}
        ]
      },
      {
        subtitulo: "Cuidados  e acessórios",
        items: [
          { name: "Brinquedos"},
          { name: "Pomada para assaduras"}
        ]
      }
    ]
  }
};
