
const editarNome = document.getElementById('editarNome');
const nomeInput = document.getElementById('nome');

editarNome.addEventListener('click', () => {
  nomeInput.removeAttribute('readonly');
  nomeInput.focus();
});


nomeInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    nomeInput.setAttribute('readonly', true);
  }
});


