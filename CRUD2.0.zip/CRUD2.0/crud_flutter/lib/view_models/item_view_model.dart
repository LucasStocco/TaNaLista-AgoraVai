import '../models/item.dart';
import '../services/item_service.dart';

class ItemViewModel {
  final ItemService _service = ItemService();

  List<Item> itens = [];
  bool isLoading = false;

  Future<void> carregar(int listaId) async {
    isLoading = true;
    itens = await _service.getByLista(listaId);
    isLoading = false;
  }
}
