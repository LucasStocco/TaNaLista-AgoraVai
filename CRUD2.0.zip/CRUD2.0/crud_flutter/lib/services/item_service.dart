import '../models/item.dart';
import '../models/produto.dart';
import '../models/categoria.dart';

class ItemService {
  Future<List<Item>> getByLista(int listaId) async {
    return [
      Item(
        id: 1,
        produto: Produto(
          id: 1,
          nome: 'Arroz',
          categoria: Categoria(id: 1, nome: 'Alimentos'),
        ),
        quantidade: 2,
        preco: 7.50,
      ),
    ];
  }
}
