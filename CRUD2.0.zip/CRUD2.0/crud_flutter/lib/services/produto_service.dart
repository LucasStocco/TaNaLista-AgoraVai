import '../models/produto.dart';
import '../models/categoria.dart';

class ProdutoService {
  Future<List<Produto>> getAll() async {
    return [
      Produto(
        id: 1,
        nome: 'Arroz',
        categoria: Categoria(id: 1, nome: 'Alimentos'),
      ),
    ];
  }
}
