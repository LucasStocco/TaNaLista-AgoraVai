import 'categoria.dart';

class Produto {
  final int? id;
  final String nome;
  final Categoria categoria;

  Produto({this.id, required this.nome, required this.categoria});

  factory Produto.fromJson(Map<String, dynamic> json) {
    return Produto(
      id: json['id'],
      nome: json['nome'],
      categoria: Categoria.fromJson(json['categoria']),
    );
  }

  Map<String, dynamic> toJson() {
    return {'nome': nome, 'categoria': categoria.toJson()};
  }
}
