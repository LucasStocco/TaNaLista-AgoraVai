import 'produto.dart';

class Item {
  final int? id;
  final Produto produto;
  final int quantidade;
  final double preco;

  Item({
    this.id,
    required this.produto,
    required this.quantidade,
    required this.preco,
  });

  factory Item.fromJson(Map<String, dynamic> json) {
    return Item(
      id: json['id'],
      produto: Produto.fromJson(json['produto']),
      quantidade: json['quantidade'],
      preco: json['preco'].toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'produto': produto.toJson(),
      'quantidade': quantidade,
      'preco': preco,
    };
  }
}
